#import <Foundation/Foundation.h>

//! Project version number for AlemiraLib.
FOUNDATION_EXPORT double AlemiraVersionNumber;

//! Project version string for AlemiraLib.
FOUNDATION_EXPORT const unsigned char AlemiraVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AlemiraLib/PublicHeader.h>


